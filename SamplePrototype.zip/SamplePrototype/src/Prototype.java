

public class Prototype {
   public static void main(String[] args) {

   }
}
