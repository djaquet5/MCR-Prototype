public abstract class MapSite {

   public abstract MapSite clone();
}
