public class MazeFactory {
}
